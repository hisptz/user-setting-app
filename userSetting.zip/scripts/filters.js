'use strict';

/* Filters */

var userSettingFilters = angular.module('userSettingFilters', []);