'use strict';

/* Directives */

var userSettingDirectives = angular.module('userSettingDirectives', []);