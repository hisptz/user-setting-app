//Controller for column show/hide
userSetting.controller('LeftBarMenuController',
        function($scope, $location) {

});